class HtmlService {
  //

  // static String quillDeltaToHtml(Delta delta) {
  //   final convertedValue = jsonEncode(delta.toJson());
  //   final markdown = deltaToMarkdown(convertedValue);
  //   final html = markdownToHtml(markdown);
  //   return html;
  // }

  // static String htmlToQuillDelta(String html) {
  //   var markdownText = html2md.convert(html);
  //   return markdownToDelta(markdownText);
  // }
}
